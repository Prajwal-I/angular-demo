import { Component, Input, OnInit } from '@angular/core';
import { WeatherDetails } from 'src/app/interfaces/weather-details';

@Component({
  selector: 'app-weather-details',
  templateUrl: './weather-details.component.html',
  styleUrls: ['./weather-details.component.scss']
})
export class WeatherDetailsComponent implements OnInit {
  @Input() weatherDetails: WeatherDetails = {} as WeatherDetails;

  constructor() { }

  ngOnInit(): void {
  }

}
