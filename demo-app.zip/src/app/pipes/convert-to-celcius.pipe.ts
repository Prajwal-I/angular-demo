import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'convertToCelcius'
})
export class ConvertToCelciusPipe implements PipeTransform {

  transform(valueFareh: number | any): string | undefined{
    if (valueFareh === undefined) return;
    return ((valueFareh-32)*(5/9)).toFixed(2);
  }

}
