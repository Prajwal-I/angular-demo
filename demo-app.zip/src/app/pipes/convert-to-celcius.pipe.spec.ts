import { ConvertToCelciusPipe } from './convert-to-celcius.pipe';

describe('ConvertToCelciusPipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertToCelciusPipe();
    expect(pipe).toBeTruthy();
  });
});
