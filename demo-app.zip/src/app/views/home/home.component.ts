import { Component, OnInit } from '@angular/core';
import { Weather, WeatherDetails } from 'src/app/interfaces/weather-details';
import { WeatherService } from 'src/app/services/weather.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  cityName = "hyderabad";
  enableWethDets = false;
  weatherDetails: WeatherDetails = {} as WeatherDetails;
  loading =false;

  constructor(private weather: WeatherService) { }

  ngOnInit(): void {
  }

  onSearch() {
    if (this.cityName){
      this.enableWethDets = true;
      this.loading = true
      this.weather.getWeather(this.cityName).subscribe((data)=> {
        this.loading = false;
        console.log(data);
        this.weatherDetails = data;
      })
    }
    else
    alert("Enter a city name")
  }

}
