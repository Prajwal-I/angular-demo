import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { WeatherDetails } from '../interfaces/weather-details';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {
  headers = {
		'X-RapidAPI-Key': '11dfd099a3msh93a196fccfb6b93p1bc3dbjsn68314ea9cae6',
		'X-RapidAPI-Host': 'weather-by-api-ninjas.p.rapidapi.com'
	}
  url = 'https://weather-by-api-ninjas.p.rapidapi.com/v1/weather?city=';

  constructor(private http: HttpClient) { }

  getWeather(cityName: string): Observable<WeatherDetails> {
    return this.http.get<WeatherDetails>(this.url+cityName, {headers: this.headers});
  }
}
